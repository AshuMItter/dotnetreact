import React from "react";

class StateDemo extends React.Component{
    constructor(props){
        super(props);
        this.state ={initvalue:10, myname:"Default Name"}       
        this.handleUpdate = this.handleUpdate.bind(this);
       
    }

     
    handleUpdate(){

       
      this.setState({myname:"new Name",initvalue:90});
       
    //   this.setState(function(curState,propVal){

        
    //      curState.initvalue = curState.initvalue +10;
    //      curState.myname = "New Name"
         
    //      return curState.initvalue, curState.myname
     
    //  })
    }


    render(){
        
    return(
        <>
        <button onClick={this.handleUpdate}>UpdateState</button>
        <h1>{this.state.initvalue}</h1>
        <h1>{this.state.myname}</h1>
   
        </>
    )
    }
}
export default StateDemo;
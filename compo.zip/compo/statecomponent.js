import React  from "react";

class  StateComponent extends React.Component{
   constructor(props){
       super(props);
       this.state = {num:0}
       this.handleChange = this.handleChange.bind(this);
   }
   handleChange(){
       this.setState(function(curSt,curProp){
           curSt.num  = curSt.num +1;
           return curSt.num ;
       })
   }
    render(){
        return (

            <div>
                
                    <input type="button" value="ChangeState" onClick={this.handleChange}/> <br/>
                    <p>{this.state.num}</p> <br />
                    <p>{this.props.key}</p>
                  
            </div>
        )
    }
}
export default StateComponent;
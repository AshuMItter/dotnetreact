import React from "react";
import Ria from "./riyacomponent";
import StateComponent from "./statecomponent";


class Demo extends React.Component{

    constructor(props){
        super(props);
        
        
    }
 

    render(){
       
       if(this.props.myname == "g"){
           return (
      <>
        <Ria />
      </>

           )
           
       }
       else{
        return (
            <>
               <h1>
              I am not GREEN.
               </h1>
            </>)
               
    }

       
        
       
         
        }
        
       

        
    }

export default Demo;
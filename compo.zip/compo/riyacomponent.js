import React from 'react';


class Ria extends React.Component{
constructor(props){
    super(props);
}

  render(){

    return (
    <>
    <h1>Hi ! I am Ria</h1>
   
    </>
    )
  }

}
export default Ria;